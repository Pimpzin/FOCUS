<?php

$cpf = $_GET['cpf'];


      $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, "https://www.amildental.com.br/ccstorex/custom/v1/sseproxysoa");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_ENCODING, "gzip"); //QUEBRAR CRIPTOGRAFIA
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/cookie.txt");
  curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/cookie.txt");
  curl_setopt($ch, CURLOPT_USERAGENT, 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'host: www.amildental.com.br',
'accept: application/json, text/javascript, */*; q=0.01',
'authorization: Bearer eyJhbGciOiJSUzI1NiIsImprdSI6InAxNDQwNzg2YzFQUkQiLCJraWQiOiIxIiwieDVjIjpudWxsLCJ4NXUiOiJodHRwczovL3d3dy5hbWlsZGVudGFsLmNvbS5ici9jY3N0b3JlL3YxL3RlbmFudENlcnRDaGFpbiJ9.eyJpYXQiOjE2MjUzNjc5OTEsImV4cCI6MTY1NjkwMzk5MSwic3ViIjoiODc4NDQyNTcxIiwiYXVkIjoic3RvcmVmcm9udFVJIiwiY29tLm9yYWNsZS5hdGcuY2xvdWQuY29tbWVyY2Uucm9sZXMiOm51bGwsIm9jY3MuYWRtaW4ucm9sZXMiOm51bGwsImlzcyI6Imh0dHBzOi8vd3d3LmFtaWxkZW50YWwuY29tLmJyLyIsIm9jY3MuYWRtaW4ubG9jYWxlIjpudWxsLCJvY2NzLmFkbWluLnR6IjpudWxsLCJvY2NzLmFkbWluLnRlbmFudFR6IjoiQW1lcmljYS9TYW9fUGF1bG8iLCJvY2NzLmFkbWluLmtlZXBBbGl2ZVVSTCI6Imh0dHBzOi8vd3d3LmFtaWxkZW50YWwuY29tLmJyLyIsIm9jY3MuYWRtaW4udG9rZW5SZWZyZXNoVVJMIjoiaHR0cHM6Ly93d3cuYW1pbGRlbnRhbC5jb20uYnIvY2NzdG9yZS92MS9zc29Ub2tlbnMvcmVmcmVzaCIsIm9jY3MuYWRtaW4udmVyc2lvbiI6IjIxLjIuNyIsIm9jY3MuYWRtaW4uYnVpbGQiOiJqZW5raW5zLUFzc2VtYmxlX0Nsb3VkX0NvbW1lcmNlX0VBUnNfLW1hc3Rlci0xMDAiLCJvY2NzLmFkbWluLmVtYWlsIjpudWxsLCJvY2NzLmFkbWluLnByb2ZpbGVJZCI6Ijg3ODQ0MjU3MSIsIm9jY3MuYWdlbnQub2JvIjpudWxsLCJvY2NzLmFkbWluLmZpcnN0TmFtZSI6bnVsbCwib2Njcy5hZG1pbi5sYXN0TmFtZSI6bnVsbCwib2Njcy5hZG1pbi5wdW5jaG91dFVzZXIiOmZhbHNlLCJzdWJfdHlwZSI6bnVsbCwic2NvcGUiOm51bGx9.Men7mXtUj37nzCoFKLtnLepDfcI1AbL7vcPKSDITmFNYIXgwGAVmH0lhSdIGXu3Ua6jOxRFILT5FvHJ+msafrgcDCNFlf3XFL5QLidiwELfTxx1e+/DjEggV8JmeXxI1BiJdQKuDL4L0yM+kvX6OSGtxhhmzNlg8HlTXr1GNIxRg2Q72hmKS+UAk2N3wYB0QwGH1VQFPzF/3EfJPTKAJyPr/MHukiphP44iK6E7IGvqhT6I4h06evU6tvgSo+nTLlYvcrFNrQIxsGWXCF9P2+DzQ8bmTqjjhr/TPE515k5O+OGn5rRnH2xkO6f6vdrBuM+ZfDacfNSfG77pQsrARNw==',
'content-type: application/json',
'cookie: ccstoreroute=13b60ac5689de76ff2dfb651284f1332; JSESSIONID=mKhveNgP-ckWRI7RbkTD09kwpZ3jvLPp6IhPY6iuEcJ_pny8pbid!-404802345; ak_bmsc=103FDCA3A6E1937132AD20DD937897AF~000000000000000000000000000000~YAAQV6QSAvBKaDt6AQAAdth4bww/UFdY7zpBoPcmrPtoTlmRcyh7LKvxtArH8T/E1WUdtTDIXOMnR0fCtwrOSYDYlZG/+A2KVMVUVoEYJYyHkpaZ3r8ADdJOuAdROhVwMxqSrh1F77sL9vv/kPtrRcL3dTKCHRtOLtUzVAfoeSbCB/YEreD9A82mROe8rFlXsDIE9/IGC1otuoeHZiGIrGiBQxq5Z4IjQsBmdiiq4FCzzqKzicli7wjtpqDtuPS+MALR87/ujixBsuNvFBJXE1V+/f/tC+Qshj0Cc2qG5LjfxRgoil6ZJA4ti14Vg9706HNNvyenYaU6RkTx6pwIPyi7NmzzY1MwwGV6MCgUDWBPN+dfEVwLEqbOIjxp4OL2uZHTZOljwZdzd13aIzE/cy78; xvp1440786c1PRD_siteUS=1c432ffe%3A17a6f33891a%3Aedc-4094297609; atgRecVisitorId=10B2hm5V2tUFy-dlPt6miPA_QlJp-356GooA7N6p4qALeUkA517; SOFT_LOGIN=eyJraWQiOiJTb2Z0TG9naW5LZXkiLCJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI4Nzg0NDI1NzEiLCJpc3MiOiJzdG9yZWZyb250VUkiLCJleHAiOjE2NTk1ODIyODUxMzcsImlhdCI6MTYyNTM2Nzg4NTEzN30%3D.bjLDkV1QupTiNU5oF9b%2FQoFvFBlnWbUam0j2psJAbDU%3D; xdp1440786c1PRD_siteUS=10B2hm5V2tUFy-dlPt6miPA_QlJp-356GooA7N6p4qALeUkA517%3A1625367838981%3A1625367838981%3A1625367838981%3A7%3A1; oauth_token_secret-storefrontUI=%22eyJhbGciOiJSUzI1NiIsImprdSI6InAxNDQwNzg2YzFQUkQiLCJraWQiOiIxIiwieDVjIjpudWxsLCJ4NXUiOiJodHRwczovL3d3dy5hbWlsZGVudGFsLmNvbS5ici9jY3N0b3JlL3YxL3RlbmFudENlcnRDaGFpbiJ9.eyJpYXQiOjE2MjUzNjc5OTEsImV4cCI6MTY1NjkwMzk5MSwic3ViIjoiODc4NDQyNTcxIiwiYXVkIjoic3RvcmVmcm9udFVJIiwiY29tLm9yYWNsZS5hdGcuY2xvdWQuY29tbWVyY2Uucm9sZXMiOm51bGwsIm9jY3MuYWRtaW4ucm9sZXMiOm51bGwsImlzcyI6Imh0dHBzOi8vd3d3LmFtaWxkZW50YWwuY29tLmJyLyIsIm9jY3MuYWRtaW4ubG9jYWxlIjpudWxsLCJvY2NzLmFkbWluLnR6IjpudWxsLCJvY2NzLmFkbWluLnRlbmFudFR6IjoiQW1lcmljYS9TYW9fUGF1bG8iLCJvY2NzLmFkbWluLmtlZXBBbGl2ZVVSTCI6Imh0dHBzOi8vd3d3LmFtaWxkZW50YWwuY29tLmJyLyIsIm9jY3MuYWRtaW4udG9rZW5SZWZyZXNoVVJMIjoiaHR0cHM6Ly93d3cuYW1pbGRlbnRhbC5jb20uYnIvY2NzdG9yZS92MS9zc29Ub2tlbnMvcmVmcmVzaCIsIm9jY3MuYWRtaW4udmVyc2lvbiI6IjIxLjIuNyIsIm9jY3MuYWRtaW4uYnVpbGQiOiJqZW5raW5zLUFzc2VtYmxlX0Nsb3VkX0NvbW1lcmNlX0VBUnNfLW1hc3Rlci0xMDAiLCJvY2NzLmFkbWluLmVtYWlsIjpudWxsLCJvY2NzLmFkbWluLnByb2ZpbGVJZCI6Ijg3ODQ0MjU3MSIsIm9jY3MuYWdlbnQub2JvIjpudWxsLCJvY2NzLmFkbWluLmZpcnN0TmFtZSI6bnVsbCwib2Njcy5hZG1pbi5sYXN0TmFtZSI6bnVsbCwib2Njcy5hZG1pbi5wdW5jaG91dFVzZXIiOmZhbHNlLCJzdWJfdHlwZSI6bnVsbCwic2NvcGUiOm51bGx9.Men7mXtUj37nzCoFKLtnLepDfcI1AbL7vcPKSDITmFNYIXgwGAVmH0lhSdIGXu3Ua6jOxRFILT5FvHJ%2BmsafrgcDCNFlf3XFL5QLidiwELfTxx1e%2B%2FDjEggV8JmeXxI1BiJdQKuDL4L0yM%2BkvX6OSGtxhhmzNlg8HlTXr1GNIxRg2Q72hmKS%2BUAk2N3wYB0QwGH1VQFPzF%2F3EfJPTKAJyPr%2FMHukiphP44iK6E7IGvqhT6I4h06evU6tvgSo%2BnTLlYvcrFNrQIxsGWXCF9P2%2BDzQ8bmTqjjhr%2FTPE515k5O%2BOGn5rRnH2xkO6f6vdrBuM%2BZfDacfNSfG77pQsrARNw%3D%3D%22; bm_sv=7959F836D5E5AD3F88707EC91BFA8403~BQPrapIoj31g/ZAgk++cbsBXMXpJKmi5CtfcQicJK+Iw2WwZwwUGZ8YMiu9Kgvq207zEmdgYVgr7+/wh/dMjpLAnHiAv+PD0uDlITFE8e7LWaY+5ikq9qUOqCBKgggXSxXQbIQMXTfuJX634utrFsAYZ+Zo+MNUAr6ansNvgOJ4=',
'origin: https://www.amildental.com.br',
'referer: https://www.amildental.com.br/checkout/',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-origin',
'sec-gpc: 1',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'x-cc-meteringmode: CC-NonMetered',
'x-ccpricelistgroup: realPriceGroup',
'x-ccprofiletype: storefrontUI',
'x-ccsite: siteUS',
'x-ccviewport: xs',
'x-ccvisitid: 1c432ffe:17a6f33891a:edc-4094297609',
'x-ccvisitorid: 10B2hm5V2tUFy-dlPt6miPA_QlJp-356GooA7N6p4qALeUkA517',
'x-requested-with: XMLHttpRequest'));
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, '{"pathParam":"propostas/ConsultaBaseCpf?cpf='.$cpf.'","callType":"GET"}');
      echo $r2 = curl_exec($ch);

//A CHAMADA AO SERVIÇO DA SISAMIL RETORNOU SEM CRÍTICA DE NEGÓCIO
//CPF OU CNPJ NÃO ENCONTRADO NA BASE

if (strpos($r2, 'A CHAMADA AO SERVIÇO DA SISAMIL RETORNOU SEM CRÍTICA DE NEGÓCIO')) {
        echo "<span class='badge badge-success'>'.$msg.'</span> <font color='black'><span class='badge badge-success'></font></span><BR>";
    flush();
    ob_flush();
  }else{
    echo "<span class='badge badge-danger'>'.$cpf.'</span> <font color='white'>NÃO ENCONTRADO<span class='badge badge-danger'></span> <br /></font>  ";
    flush();
    ob_flush();
}
?>