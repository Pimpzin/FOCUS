<?php

function GetStr($string, $start, $end){
$str = explode($start, $string);
$str = explode($end, $str[1]);  
return $str[0];
}
error_reporting(0);
/**************
Coded by: @Pimposo
***************/
$get = $_GET["lista"];
$split = explode("|", $get);
$nome = $split[0];

$nome = str_replace(' ', '%20', $nome);

 $getnomeDuality = file_get_contents("https://dualityapi.xyz/apis/teste/Consultas%20Privadas/JSON/nascimento.php?consulta=$nome");

 $resp= str_replace(array('":"'), ': ', $getnomeDuality);
 $resp2 = str_replace(array('","'), '</br>', $resp);
 $resp3 = str_replace(array('\r"}', '{"', '[', ']'), '', $resp2);
 $resp4 = str_replace(array('\/'), '/', $resp3);
 $resp5 = str_replace(array(','), '</br></br>', $resp4);


if(strpos($getnomeDuality, 'CPF')){
    echo "CONSULTA REALIZADA!</br></br>$resp5";
}else{
    echo "NOME NÃO ENCONTRADO!";
}

?>